import { useState } from "react";
import "./styles.css";

function App() {
  const [products, setProducts] = useState([]);
  const [newProduct, setNewProduct] = useState("");
  const [editIndex, setEditIndex] = useState(null);

  const handleAdd = () => {
    if (newProduct.trim() === "") return;
    if (editIndex !== null) {
      const updated = [...products];
      updated[editIndex] = newProduct;
      setProducts(updated);
      setEditIndex(null);
    } else {
      setProducts([...products, newProduct]);
    }
    setNewProduct("");
  };

  const handleDelete = (index) => {
    const updated = products.filter((_, i) => i !== index);
    setProducts(updated);
  };

  const handleEdit = (index) => {
    setNewProduct(products[index]);
    setEditIndex(index);
  };

  return (
    <div className="container">
      <h1>Manajemen Data Produk</h1>
      <div className="form">
        <input
          type="text"
          value={newProduct}
          placeholder="Masukkan nama produk"
          onChange={(e) => setNewProduct(e.target.value)}
        />
        <button onClick={handleAdd}>
          {editIndex !== null ? "Update Produk" : "Tambah Produk"}
        </button>
      </div>

      <ul className="product-list">
        {products.length === 0 ? (
          <p className="empty">Belum ada data produk</p>
        ) : (
          products.map((product, index) => (
            <li key={index}>
              <span>{product}</span>
              <div>
                <button onClick={() => handleEdit(index)}>Edit</button>
                <button onClick={() => handleDelete(index)}>Hapus</button>
              </div>
            </li>
          ))
        )}
      </ul>
    </div>
  );
}

export default App;
